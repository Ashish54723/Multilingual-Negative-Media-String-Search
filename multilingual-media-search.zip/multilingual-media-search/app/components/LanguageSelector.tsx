
const languages = [
  'English', 'Hindi', 'Spanish', 'French', 'German', 'Chinese', 'Arabic', 'Portuguese', 'Russian', 'Japanese'
];

export default function LanguageSelector({ setLang }: { setLang: (lang: string) => void }) {
  return (
    <div className="mb-4">
      <select
        onChange={(e) => setLang(e.target.value)}
        className="w-full p-2 rounded-xl shadow-inner"
      >
        <option value="English">English (Default)</option>
        {languages.map(lang => (
          <option key={lang} value={lang}>{lang}</option>
        ))}
      </select>
    </div>
  );
}
