
export function generateSearchURL(name: string, query: string, lang: string): string {
  const base = 'https://www.google.com/search?q=';
  const langParam = lang !== 'English' ? `&lr=lang_${lang.toLowerCase()}` : '';
  return `${base}${encodeURIComponent(name + ' ' + query)}${langParam}`;
}

export function downloadCSV(urls: string[]) {
  const csvContent = 'data:text/csv;charset=utf-8,' + urls.map(u => `"${u}"`).join('\n');
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', 'search_results.csv');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function copyToClipboard(text: string) {
  navigator.clipboard.writeText(text).then(() => alert('Copied to clipboard!'));
}
